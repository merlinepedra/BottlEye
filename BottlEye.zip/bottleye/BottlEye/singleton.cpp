#include "singleton.hpp"

battleye::emulator singleton::emulator = battleye::emulator();