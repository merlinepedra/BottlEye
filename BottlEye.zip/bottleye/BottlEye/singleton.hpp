#pragma once
#include "emulator.hpp"

namespace singleton
{
	extern battleye::emulator emulator;
}